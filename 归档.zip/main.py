import re
from datetime import datetime
try:
    import fitz  # PyMuPDF for redaction
except ModuleNotFoundError:
    print("请安装 PyMuPDF 库：pip install PyMuPDF")
    exit(1)

def extract_codes(pdf_path):
    blocks = []
    pairs = []
    css_list = []
    quantity_list = []
    weight_list = []
    doc = fitz.open(pdf_path)

    for page_num in range(len(doc)):
        page = doc[page_num]
        text = page.get_text()
        # Find all matches for CSS# IATA MAWB Quantity Weight
        matches = list(re.finditer(r'\b(\w+)\s+(\d{3})\s+(\d{8})\s+(\d+)\s+([\d.]+)\b', text))
        for i, match in enumerate(matches):
            start = match.start()
            # Find the end as the position of "Total" after start
            text_after = text[start:]
            total_match = re.search(r'\bTotal\b', text_after)
            if total_match:
                end = start + total_match.end()
            else:
                end = matches[i+1].start() if i+1 < len(matches) else len(text)
            block = text[start:end].strip()
            blocks.append(block)
            css = match.group(1)
            css_list.append(css)
            iata = match.group(2)
            mawb = match.group(3)
            quantity = match.group(4)
            weight = match.group(5)
            quantity_list.append(quantity)
            weight_list.append(weight)
            pairs.append(f"{iata}-{mawb}")

    return blocks, pairs, css_list, quantity_list, weight_list, doc

def redact_codes(doc, lines_to_redact, output_path):
    for page_num in range(len(doc)):
        page = doc[page_num]
        for line in lines_to_redact:
            # Search for the entire line as a whole
            text_instances = page.search_for(line)
            for inst in text_instances:
                # Add a redaction annotation (black rectangle)
                page.add_redact_annot(inst, fill=(0, 0, 0))  # Black fill
        # Apply redactions
        page.apply_redactions()
    doc.save(output_path)
    doc.close()

if __name__ == "__main__":
    # Specified codes to redact, e.g., ['016-57523933', '079-50699283']
    specified_codes = ['016-57523933', '079-50699283', '576-68103022','180-52255140']

    blocks, pairs, css_list, quantity_list, weight_list, doc = extract_codes('AIR-0000419501 CES INVOICE.pdf')
    print("IATA-MAWB Pairs:", pairs)

    print("All bill sections:")

    lines_to_redact = []
    for spec in specified_codes:
        if spec in pairs:
            idx = pairs.index(spec)
            lines_to_redact.append(blocks[idx])

    print("Blocks to redact:")
    for block in lines_to_redact:
        print(block)
        print("---")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_path = f'AIR-0000419501 CES INVOICE_redacted_{timestamp}.pdf'

    redact_codes(doc, lines_to_redact, output_path)
